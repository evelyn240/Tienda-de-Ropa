<html>
<head>
	<Title>mis datos</Title>
</head>
<body>
	<table align="CENTER" border="0"style="border-collapse: collapse;">
		<tr> 
			<td>            TICKET DE COMPRA         </td>
		</tr>
		<tr>
			<td>**********************</td>
		</tr>
		<tr>
			<td> ***TIENDA DE ROPA***</td>
		</tr>
		<tr>
			<td> Fecha </td>
		</tr>
		<tr>
			<td>4 Enero 2022</td>
		</tr>
		<tr>
			<td>- Producto</td>
		</tr>
		<tr>
			<td>Blusa Color Rosa con botones</td>
		</tr>
		<tr>
			<td>- Precio Unitario</td>
		<tr>
			<td> 150</td>
		</tr>
        <tr>
			<td>Costo Total</td>
		</tr>
		<tr>
			<td> 300</td>
		</tr>
		<tr>
			<td>IVA .16%</td>
		</tr>
		<tr>
			<td>**********************</td>
		</tr>

		</tr>
	</table>
</body>
</html>