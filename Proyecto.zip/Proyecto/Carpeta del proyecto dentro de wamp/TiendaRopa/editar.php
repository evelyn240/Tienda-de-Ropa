<?php
if(isset($_GET['editar'])){
	$editar_id = $_GET['editar'];

	$consulta = "SELECT * FROM producto WHERE Id = 'editar_id'";
	$ejecutar = mysqli_query($con, $consulta);

	$fila = mysqli_fetch_array($ejecutar);

    $no_producto = $fila['no_producto'];
	$nom = $fila['nombre'];
	$des = $fila['descripcion'];
    $stock = $fila['stock'];
	$prec = $fila['precio'];
	$no = $fila['imagen'];
}
?>
<br />
<form method="POST" action="Producto.php">
	<label>#_PRODUCTO:<br> </label>
	<input type="text" name="no_producto" value="<?php echo $no_producto; ?>"><br />
	<label>PRODUCTO:<br> </label>
	<input type="text" name="nombre" value="<?php echo $nom; ?>"><br />
	<label>CARACTERISTICAS:<br> </label>
	<textarea style="border-radius: 10px;" rows="3" cols="50" name="descripcion" value="<?php echo $des; ?>"></textarea><br />
<label>STOCK:<br> </label>
<input type="text" name="stock" value="<?php echo $stock; ?>"><br />
<label>CANTIDAD:<br> </label>
<input type="text" name="precio" value="<?php echo $prec; ?>"><br />
<input type="file" name="imagen" value="<?php echo $no; ?>"><br />
<input type="submiT" name="actualizar" value="ACTUALIZAR DATOS">
</form>

<?php
if (isset($_POST['actualizar'])){
	$actualizar_no_producto = $_POST['no_producto'];
$actualizar_nom = $_POST['nombre'];
$actualizar_des = $_POST['descripcion'];
$actualizar_stock = $_POST['stock'];
$actualizar_precio = $_POST['precio'];
$actualizar_no = $_POST['imagen'];

$actualizar = "UPDATE producto SET no_producto='$actualizar_no_producto', nombre='$actualizar_nom', descripcion='$actualizar_des', stock='$actualizar_stock', precio='$actualizar_precio', imagen='$actualizar_no' WHERE Id='$editar_id'";
$ejecutar = mysqli_query($con, $actualizar);

if ($ejecutar){
	echo "<script>alert('Datos Actualizados!')</script>";
	echo "<script>windoows.open('Producto.php','_self')</script>";
}
}
?>
