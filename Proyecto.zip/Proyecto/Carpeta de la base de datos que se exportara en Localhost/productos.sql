-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 04-01-2022 a las 19:12:00
-- Versión del servidor: 5.5.8
-- Versión de PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `productos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE IF NOT EXISTS `producto` (
  `Id` int(100) NOT NULL AUTO_INCREMENT,
  `no_producto` int(100) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `stock` int(100) NOT NULL,
  `precio` int(100) NOT NULL,
  `imagen` longtext NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Volcar la base de datos para la tabla `producto`
--

INSERT INTO `producto` (`Id`, `no_producto`, `nombre`, `descripcion`, `stock`, `precio`, `imagen`) VALUES
(8, 1, 'Blusa Color Rosa con botones', ' Blusa para dama talla chica', 2, 150, 'Blusa rosa.jpg');
